import React from 'react';

const Inventory = () => {
    return (
        <div>
            <h1>Inventory coming soon...</h1>
        </div>
    );
};

export default Inventory;