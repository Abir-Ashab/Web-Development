const firebaseConfig = {
    apiKey: "AIzaSyDrnTlaFOThHGej0ZkIglLffFZZioNSPiI",
    authDomain: "ema-test-jkr.firebaseapp.com",
    databaseURL: "https://ema-test-jkr.firebaseio.com",
    projectId: "ema-test-jkr",
    storageBucket: "ema-test-jkr.appspot.com",
    messagingSenderId: "273630571694",
    appId: "1:273630571694:web:dd5435e9e8b7deb372913f"
  };
export default firebaseConfig;