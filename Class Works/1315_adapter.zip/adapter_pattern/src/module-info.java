module adapter_pattern {
}